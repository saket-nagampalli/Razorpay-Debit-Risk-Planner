"""Generate 12 months of business-as-usual history (Oct 2025 - Sep 2026)."""
import pickle, sys
import numpy as np
import pandas as pd
import sim

def run(scale=1.1, save=True, verbose=True):
    sim.GLOBAL_INS_SCALE = scale
    rng = np.random.default_rng(42)
    cust = sim.all_customers(rng)
    state = sim.new_state(0)
    sim.extend_state(state, len(cust), cust)
    logs = []
    for c in range(1, 13):
        U = sim.uniforms(c, len(cust))
        sim.pre_cycle(cust, state, c, U)
        acts = sim.bau_actions(cust, state)
        logs.append(sim.step(cust, state, c, acts, U))
        if c == 10 and save:
            with open("data/snapshot_after_c10.pkl", "wb") as f:
                pickle.dump(dict(cust=cust.copy(), state={k: v.copy() for k, v in state.items()}), f)
        # joiners replace cancelled subscribers (new customers have no history)
        if c < 12:
            jr = np.random.default_rng(5000 + c)
            last = logs[-1]
            new = []
            sid = len(cust)
            for m, k in last.groupby("merchant")["cancelled"].sum().items():
                if k > 0:
                    nc = sim.make_customers(jr, m, int(k), cycle_joined=c + 1, start_id=sid, prior_tenure=False)
                    sid += int(k)
                    new.append(nc)
            if new:
                new = pd.concat(new, ignore_index=True)
                cust = pd.concat([cust, new], ignore_index=True)
                sim.extend_state(state, len(new), new)
        if verbose:
            L = logs[-1]
            print(c, len(L), "fail%", round(L.first_attempt_failed.mean() * 100, 1),
                  "UPI", round(L[L.rail == 'UPI'].first_attempt_failed.mean() * 100, 1),
                  "lost%", round((L.stage == 'lost').mean() * 100, 1), "cancel%", round(L.cancelled.mean() * 100, 2))
    log = pd.concat(logs, ignore_index=True)
    if save:
        with open("data/snapshot_after_c12.pkl", "wb") as f:
            pickle.dump(dict(cust=cust.copy(), state={k: v.copy() for k, v in state.items()}), f)
        log.to_parquet("data/debits_bau.parquet", index=False)
        cust.to_csv("data/customers.csv", index=False)
    return log, cust

if __name__ == "__main__":
    run(float(sys.argv[1]) if len(sys.argv) > 1 else 1.1)
