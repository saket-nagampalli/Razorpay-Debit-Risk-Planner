"""Sanity checks and headline numbers for the README / product note."""
import json
import numpy as np
import pandas as pd

LTV = 6
L = pd.read_parquet("data/debits_bau.parquet"); h = L[L.cycle >= 3]
P = pd.read_parquet("data/policy_sim.parquet"); P = P[P.holdout == 0]
out = {}
m = h.archetype.isin(["salaried_monthend", "salaried_5to10"])
out["history"] = dict(
    rows=len(L), subscribers=int(L.cust_id.nunique()),
    first_fail_by_rail=h.groupby("rail").first_attempt_failed.mean().round(3).to_dict(),
    upi_reason_share=h[(h.rail == "UPI") & (h.first_attempt_failed == 1)].first_attempt_reason.value_counts(normalize=True).round(3).to_dict(),
    paid_eventually_after_failure=round(h[h.first_attempt_failed == 1].stage.isin(["retry", "recovered"]).mean(), 3),
    monthly_cancel_rate=round(h.cancelled.mean(), 4),
    fail_by_days_since_payday_salaried={str(k): round(float(v), 3) for k, v in h[m].groupby(
        pd.cut((h[m].debit_day - h[m].payday_true) % 30, [-1, 2, 10, 19, 27, 30]), observed=True).first_attempt_failed.mean().items()},
    fail_by_archetype=h.groupby("archetype").first_attempt_failed.mean().round(3).to_dict())
b = P[(P.arm == "BAU") & (P.cycle == 11)].set_index("cust_id"); g = L[L.cycle == 11].set_index("cust_id")
common = b.index.intersection(g.index)
out["check_bau_arm_matches_history"] = float((b.loc[common, "first_attempt_code"] == g.loc[common, "first_attempt_code"]).mean())
rows = []
for arm, x in P.groupby("arm"):
    rows.append(dict(arm=arm, collected=x.collected_amount.sum(), cancel_ltv=(x.cancelled * x.amount * LTV).sum(),
                     msg=x.msgs.sum() * 0.5, rec=x.recovery_cost.sum()))
c = pd.DataFrame(rows).set_index("arm"); base = c.loc["BAU"]
comp = pd.DataFrame({"extra_cash_collected": c.collected - base.collected,
                     "cancellations_avoided_value": -(c.cancel_ltv - base.cancel_ltv),
                     "message_cost": -c.msg, "recovery_cost_saved": base.rec - c.rec})
comp["net"] = comp.sum(1)
out["value_components_lakh_main_run"] = (comp / 1e5).round(2).to_dict("index")
sk = P[P.merchant == "SkillUp"]; r = []
for arm in ["BAU", "R2_rules", "MODEL_NET"]:
    x = sk[sk.arm == arm]
    r.append(dict(arm=arm, debits_per_month=len(x) / 2, billed_per_month=x.amount.sum() / 2,
                  collection_rate=x.collected_amount.sum() / x.amount.sum(), first_attempt_success=1 - x.first_attempt_failed.mean(),
                  lost_per_month=(x.stage == "lost").sum() / 2, cancels_per_month=x.cancelled.sum() / 2,
                  msgs_per_month=x.msgs.sum() / 2, cash_per_month=x.collected_amount.sum() / 2))
out["skillup_per_month"] = pd.DataFrame(r).set_index("arm").round(3).to_dict("index")
json.dump(out, open("out/sanity_and_headlines.json", "w"), indent=1, default=float)
print(json.dumps(out, indent=1, default=float))
