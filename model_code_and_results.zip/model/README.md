# Debit Risk Planner: synthetic data, risk model, policy simulation and sensitivity analysis

Razorpay AI x PM Build Challenge, Track 2. Updated 9 Oct 2026 (v2: calibrated to public data, plus sensitivity analysis).

**Everything here is synthetic.** It shows the mechanism and the decision logic; it is not evidence of real-world impact. Real impact must be measured with a holdout pilot on Razorpay data.

## What was built

1. **Simulator (`sim.py`, `generate.py`).** 5 merchants, ~40,000 active subscribers, 12 monthly billing cycles (Oct 2025 – Sep 2026), 480,000 scheduled debits. Customers churn and are replaced by new joiners.
2. **Risk model (`model.py`).** Two LightGBM models: P(first attempt fails) and P(fails for insufficient funds), calibrated with isotonic regression. Trained on cycles 3–8, calibrated on 9–10, tested out-of-time on 11–12. Two versions: merchant data only, and with a Razorpay network timing signal.
3. **Policy simulation (`evaluate.py`, `robustness.py`).** Every policy starts from the same state and sees the same random events, so differences come only from the policy. Five reruns with different random draws give ranges.
4. **Sensitivity analysis (`sensitivity.py`, `learning_check.py`).** Changes the simulated world while keeping the planner's assumptions fixed, then checks whether learning from the holdout recovers.
5. **Prototype data (`export.py`).** SkillUp's plan for debits due 1–7 Oct 2026, scored on 24 Sep, including Priya.
6. **Charts (`charts.py`)** and headline numbers (`headlines.py`).

## What is calibrated to public data, and what is assumed

| Element | Value used | Source / status |
|---|---|---|
| Later-debit failure on UPI AutoPay | ~20% | Razorpay blog, Mar 2026 (calibration target) |
| Failures that are "business" declines (mostly low balance) | ~67% of UPI failures | Business Standard, Sep 2025: ~74% of AutoPay declines are business declines |
| Technical declines by bank tier | Large private 0.15%, large public-sector 0.9%, small / payments banks 3.5% per attempt, plus outage days | NPCI UPI data for Mar 2025 via Hindu BusinessLine / Outlook Business: HDFC 0.02%, Axis 0.03%, ICICI 0.13%, SBI 0.9%, Bandhan 2.48%, Jio Payments Bank 7.23% |
| Customer income types | ~55% salaried, ~30% irregular (self-employed / casual), plus students and affluent per merchant | PLFS 2023-24, urban workers: 47.5% regular wage/salaried, 40.4% self-employed, 12.1% casual. Tilted slightly to salaried because subscription payers skew formal |
| Reminder effect | −28% low-balance failure risk if read; 70% read rate (≈ −20% if sent) | Within published range: generic SMS reminders showed no significant effect (Karlan, Morten & Zinman, Philippines); reminders raised on-time payment ~9% (Cadena & Schoar, Uganda, 1,121 borrowers); personalised reminders cut unpaid loans 41% |
| Failure risk by days since payday | ×0.6 just after payday → ×2.0 just before | Assumption (practitioner guidance only; no public data) |
| Reminder fatigue | +0.75 pt cancellation risk if a low-risk customer is reminded | Assumption; no public data found |
| Cancellation after a failure | 1% on time, 3% paid on retry, 8% via recovery link, 30–50% if never collected | Assumption, consistent with ~26% of subscription churn being involuntary (Recurly) |
| Razorpay timing signal | Visible for 60% of payers, payday within ±1–2 days | Assumption; tested in sensitivity |
| Value of a cancellation | 6 more months of billing | Assumption |

**Calibration check (history, cycles 3–12):** first-attempt failure UPI 20.0%, card 11.9%, eNACH 21.4%. UPI failure reasons: insufficient funds 67%, technical 16%, notification 6%, mandate paused 5%, limit exceeded 4%, account issue 2%. Salaried customers fail 11.5% of the time just after payday and 21.9% just before it; irregular earners fail 27.5% of the time.

## Results

### Risk model (out-of-time test, Aug–Sep 2026)

| | Merchant data only | + Razorpay timing signal |
|---|---|---|
| AUC | 0.735 | 0.745 |
| KS | 0.36 | 0.37 |
| Failures caught in riskiest 20% of debits | 49% | 49% |

Well calibrated: predicted and actual failure rates match in every decile (chart 2).

### Policies (2 months, ~40k subscribers, mean of 5 runs)

Net value = extra cash collected + value of cancellations avoided − message and recovery costs.

| Policy | Net value vs today (range) | Low-balance failures prevented | Cancellations | Messages |
|---|---|---|---|---|
| Rule: remind everyone | **−₹5.6 L** (−9.1 to −3.3) | 19% | **+7%** | 60.7k |
| Rule: smarter retries + mandate fixes | ₹57.2 L | −1% | −15% | 0.7k |
| Rules: + remind if failed last month | ₹62.7 L (56.1 to 65.6) | 5% | −16% | 6.9k |
| Planner, merchant data only | ₹62.1 L | 12% | −15% | 24.2k |
| **Planner + Razorpay timing signal** | **₹65.6 L** (58.2 to 72.7) | **13%** | **−16%** | **25.3k** |
| Planner + one-time date move | ₹65.6 L | 13% | −16% | 25.7k |

Planner minus best rules, by run: +2.1, 0.0, +0.1, +7.9, +4.3 L (average +2.9 L, ~+5%).

Main run, Planner vs today: collection rate 93.8% → 95.9%, debits never collected −33%, cancellations −17%. About 39% of the value is extra cash collected in the window; 61% is subscribers not lost.

**Inside the Planner arm, treated vs 10% holdout:** collection rate 95.9% vs 94.3%; never collected 3.5% vs 5.1%; cancellations 2.75% vs 2.96% per debit.

### SkillUp, per month (~6,700 debits, ₹1.76 Cr billed)

| | Today | Best rules | Planner |
|---|---|---|---|
| First-attempt success | 77.4% | 79.4% | 80.7% |
| Collection rate | 92.4% | 94.8% | 95.2% |
| Debits never collected | 487 | 341 | 313 |
| Cancellations | 300 | 244 | 245 |
| Cash collected | ₹1.62 Cr | ₹1.67 Cr | ₹1.68 Cr (+₹5.8 L vs today) |
| Messages | 0 | 918 | 3,859 |

### By segment (Planner vs today, % of billed revenue)

Edtech 8.3%, fitness 6.2%, insurance/SIP 5.5%, D2C 5.0%, OTT 4.4%.

### Sensitivity: Planner minus best rules (₹ lakh, 2 months, mean of 2 runs)

| Scenario | Planner with fixed assumptions | After learning from the holdout |
|---|---|---|
| Base case | **+3.2** | – |
| Reminders have no effect | −4.0 | **+5.3** |
| Reminders work half as well | −0.6 | **+0.9** |
| Reminders work twice as well | +9.9 | +9.9 |
| No reminder fatigue | +11.3 | – |
| Reminder fatigue 3x | −11.5 | **+1.0** |
| Failures cause half the cancellations | −2.0 | – |
| Failures cause 1.5x the cancellations | +7.3 | – |
| Timing signal for 30% of payers (not 60%) | +0.5 | – |
| Timing signal off by ~3 days | +1.0 | – |
| No timing signal at all | −0.7 | – |
| Pessimistic combined | −13.0 | – |

"After learning" = the planner's assumptions about reminder effect and fatigue are updated to what the holdout would measure.

## What the results mean for the pitch (honest reading)

1. **Most of the value comes from acting before and around the debit.** Spacing retries past likely paydays and fixing mandate problems before the debit gets ~87% of the gain. These belong in the Planner as deterministic guardrail rules.
2. **"Remind everyone" destroys value.** It prevents the most failures but raises cancellations 7%, so it nets negative. Targeting is where AI earns its place.
3. **The AI's edge over good rules is modest (~5%) and depends on one thing: how customers respond to reminders.** If reminders work worse, or annoy people more, than assumed, a planner with fixed assumptions loses to rules.
4. **The learning loop is what makes the AI safe.** Once the planner updates its assumptions from the holdout, it beats the best rules in every scenario tested, including "reminders have no effect" (it simply stops sending them). This is the strongest answer to "how does the system learn" and "why AI over a fixed rule": a rule can't adapt to what it measures.
5. **The Razorpay timing signal is a small edge, not the headline.** In the base case it is what puts the planner ahead of rules (+3.2 L with it, −0.7 L without), but the margin shrinks as the signal gets noisier (+1.0 L if off by ~3 days, ~0 if off by ~6). With a realistic share of irregular earners (PLFS), payday timing explains less of the failure risk than in the first version.
6. **The date move doesn't pay off.** Ship it off by default.
7. **Message volume is the trade-off.** For high-ticket SkillUp the Planner reminds ~58% of debits a month. The merchant needs a per-customer cap on the policy screen, and the learning loop should be allowed to reduce volume.

## How to validate with real data (pilot design)

- 3 pilot merchants (edtech, fitness, D2C), 4–8 weeks, 10% randomised holdout stratified by risk decile.
- Start conservative: reminders only to the top risk decile; widen as measured uplift justifies.
- Measure: first-attempt success, collection rate, never-collected debits, cancellations within 30 days, opt-outs, messages per debit.
- Recalibrate the model weekly; update reminder-effect and fatigue estimates from the holdout every 2 weeks.

## Sources

- Razorpay, UPI AutoPay with Intelligent Revenue-Protect (Mar 2026): https://razorpay.com/blog/upi-autopay-with-intelligent-revenue-protect/
- Outlook Business, UPI transaction failures: how India's banks performed in FY25 (Apr 2025, citing NPCI data via Hindu BusinessLine): https://www.outlookbusiness.com/amp/story/ampstories/news/upi-transaction-failures-how-indias-banks-performed-in-fy25
- PLFS 2023-24 urban status-in-employment shares, as compiled in Research Square preprint rs-10012589: https://www.researchsquare.com/article/rs-10012589/latest
- Cadena & Schoar, Remembering to Pay? (NBER w17020): https://www.nber.org/papers/w17020 ; J-PAL summary: https://www.povertyactionlab.org/print/pdf/node/1576
- Karlan, Morten & Zinman, A Personal Touch: Text Messaging for Loan Repayment (J-PAL summary): https://www.povertyactionlab.org/print/pdf/node/1604?lang=en
- Business Standard on UPI AutoPay business declines (Sep 2025) and Recurly churn benchmarks: see research dossier.

## How to rerun

```
pip install lightgbm pandas numpy scikit-learn pyarrow matplotlib
python generate.py        # history + snapshots (~10 s)
python model.py           # both models
python evaluate.py        # main policy comparison (~4 min)
python robustness.py      # 5 runs (~8 min)
python sensitivity.py     # 13 scenarios x 2 runs (~6 min)
python learning_check.py  # learned-planner runs (~3 min)
python export.py          # prototype JSON
python headlines.py; python charts.py
```

## Files

- `data/debits_bau.parquet` – full 12-month debit log (features, outcomes, hidden truth columns)
- `data/skillup_debits_jul_sep_2026.csv` – readable SkillUp sample
- `data/customers.csv` – subscriber attributes (archetype, payday and stress are hidden truth)
- `out/model_metrics*.json`, `model_deciles*.csv`, `model_calibration*.csv`, `feature_importance*.csv`
- `out/policy_summary.csv`, `policy_by_segment.csv`, `policy_skillup.csv`, `ab_test_per_debit.csv`, `robustness_by_seed.csv`
- `out/sensitivity_summary.csv`, `sensitivity_runs.csv`, `learning_check.csv`, `sanity_and_headlines.json`
- `out/prototype_week_plan.json`, `out/prototype_priya.json` – data for the prototype screens
- `charts/` – five PNG charts
