"""Static charts for the product note / video (PNG, light theme)."""
import json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e6e5e1", "#fcfcfb"
BLUE, GRAY, RED = "#2a78d6", "#b9b8b2", "#e34948"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "figure.facecolor": SURF, "axes.facecolor": SURF})


def clean(ax, grid_axis="x"):
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


# 1. Value vs BAU by policy (mean of 5 random-draw runs, min-max whiskers)
r = pd.read_csv("out/robustness_by_seed.csv")
names = {"R1_remind_all": "Rule: remind everyone", "RULE_RETRY_PROMPTS": "Rule: smarter retries + mandate fixes",
         "R2_rules": "Rules: + remind if failed last month", "MODEL": "Planner: merchant data only",
         "MODEL_NET": "Planner: + Razorpay timing signals", "MODEL_NET_SHIFT": "Planner + one-time date move"}
g = r[r.arm != "BAU"].groupby("arm").value_vs_BAU.agg(["mean", "min", "max"]).loc[list(names)] / 1e5
fig, ax = plt.subplots(figsize=(9.5, 3.8))
y = range(len(g))[::-1]
cols = [BLUE if a == "MODEL_NET" else GRAY for a in g.index]
ax.barh(list(y), g["mean"], color=cols, height=0.55)
ax.errorbar(g["mean"], list(y), xerr=[g["mean"] - g["min"], g["max"] - g["mean"]], fmt="none", ecolor=INK2, lw=1, capsize=3)
ax.set_yticks(list(y)); ax.set_yticklabels([names[a] for a in g.index], color=INK)
for yi, m, mx in zip(y, g["mean"], g["max"]):
    ax.text(max(mx, 0) + 1.2, yi, (f"₹{m:,.1f} L" if m >= 0 else f"−₹{-m:,.1f} L"), va="center", color=INK, fontsize=9)
ax.set_xlim(-10, 72)
ax.axvline(0, color=INK2, lw=0.8)
ax.set_xlabel("Net value vs today, ₹ lakh over 2 months, 40k subscribers (mean of 5 runs; whiskers = range)")
fig.suptitle("Acting before the debit drives most of the value; AI adds ~5% on top of good rules", x=0.01, ha="left", color=INK, fontsize=11)
clean(ax); fig.tight_layout(); fig.savefig("charts/1_value_by_policy.png", dpi=180); plt.close(fig)

# 2. Risk deciles
d = pd.read_csv("out/model_deciles_net.csv").sort_values("decile")
fig, ax = plt.subplots(figsize=(7, 3.4))
ax.bar(d.decile, d.actual_fail * 100, color=BLUE, width=0.7)
ax.plot(d.decile, d.avg_pred * 100, "o", color=INK, ms=4, label="Predicted")
avg = (d.actual_fail * d.debits).sum() / d.debits.sum() * 100
ax.axhline(avg, color=INK2, lw=0.8, ls="--"); ax.text(1, avg + 1.5, f"average {avg:.0f}%", color=INK2, fontsize=9)
ax.set_xticks(d.decile); ax.set_xlabel("Risk decile (1 = safest, 10 = riskiest)"); ax.set_ylabel("First-attempt failure, %")
ax.set_title("Risk score separates safe and risky debits (out-of-time test, Aug-Sep 2026)", loc="left", color=INK, fontsize=11)
ax.legend(frameon=False, loc="upper left", labels=["Predicted", "Actual"], handles=[ax.lines[0], ax.patches[0]])
clean(ax, "y"); fig.tight_layout(); fig.savefig("charts/2_risk_deciles.png", dpi=180); plt.close(fig)

# 3. Segment value
s = pd.read_csv("out/policy_by_segment.csv").sort_values("value_pct_of_billed")
lab = {"edtech": "Edtech", "fitness": "Fitness", "d2c": "D2C replenishment", "insurance_sip": "Insurance / SIP", "ott": "OTT"}
fig, ax = plt.subplots(figsize=(7, 3.0))
ax.barh([lab[c] for c in s.category], s.value_pct_of_billed * 100, color=[BLUE if c == "edtech" else GRAY for c in s.category], height=0.55)
for i, (v, t) in enumerate(zip(s.value_pct_of_billed * 100, s.avg_ticket)):
    ax.text(v + 0.15, i, f"{v:.1f}%  (avg ticket ₹{t:,.0f})", va="center", color=INK, fontsize=9)
ax.set_xlabel("Net value as % of billed revenue (Planner vs today)"); ax.set_xlim(0, 10.5)
ax.set_title("Biggest gain for edtech: high ticket relative to customers' budgets", loc="left", color=INK, fontsize=11)
clean(ax); fig.tight_layout(); fig.savefig("charts/3_value_by_segment.png", dpi=180); plt.close(fig)

# 4. Reminders: volume vs failures prevented vs cancellations
p = pd.read_csv("out/policy_summary.csv").set_index("arm")
sel = ["R1_remind_all", "R2_rules", "MODEL_NET"]
lbl = ["Remind\neveryone", "Remind if failed\nlast month", "Planner\n(AI-targeted)"]
fig, axs = plt.subplots(1, 3, figsize=(10, 3.0))
for ax, col, title, fmt in [(axs[0], "messages", "Reminders sent", "{:,.0f}"),
                            (axs[1], "failures_prevented_pct", "Low-balance failures prevented", "{:.0%}"),
                            (axs[2], "cancellations_vs_BAU_pct", "Change in cancellations", "{:+.0%}")]:
    v = p.loc[sel, col]
    ax.bar(range(3), v, color=[GRAY, GRAY, BLUE], width=0.6)
    for i, x in enumerate(v):
        ax.annotate(fmt.format(x), (i, x), xytext=(0, 3 if x >= 0 else -3), textcoords="offset points",
                    ha="center", va="bottom" if x >= 0 else "top", color=INK, fontsize=9)
    lo, hi = min(v.min(), 0), max(v.max(), 0)
    ax.set_ylim(lo - (hi - lo) * 0.18, hi + (hi - lo) * 0.18)
    ax.set_xticks(range(3)); ax.set_xticklabels(lbl, fontsize=8)
    ax.set_title(title, loc="left", color=INK, fontsize=10); ax.set_yticks([]); clean(ax, "y")
    ax.axhline(0, color=INK2, lw=0.8)
fig.tight_layout(); fig.savefig("charts/4_reminder_targeting.png", dpi=180); plt.close(fig)
# 5. Sensitivity: planner advantage over the best rules, fixed beliefs vs after learning
sv = pd.read_csv("out/sensitivity_summary.csv").set_index("scenario")
lc = pd.read_csv("out/learning_check.csv").set_index("scenario")
order = ["Base case", "Reminders have no effect", "Reminders work half as well", "Reminders work twice as well",
         "No reminder fatigue", "Reminder fatigue 3x", "Failures cause half the cancellations",
         "Failures cause 1.5x the cancellations", "Timing signal for 30% of payers (not 60%)",
         "Timing signal off by ~3 days", "No timing signal at all", "Pessimistic combined"]
v = sv.loc[order, "planner_minus_rules"]
fig, ax = plt.subplots(figsize=(9.5, 5.2))
y = list(range(len(order)))[::-1]
ax.barh(y, v, color=[BLUE if x >= 0 else GRAY for x in v], height=0.55, label="Planner with fixed assumptions")
for yi, n, x in zip(y, order, v):
    ax.text(x + (0.4 if x >= 0 else -0.4), yi, f"{x:+.1f}", va="center", ha="left" if x >= 0 else "right", color=INK, fontsize=9)
    key = n if n in lc.index else ("Pessimistic combined (reminder part)" if n == "Pessimistic combined" else None)
    if key and n != "Pessimistic combined" and abs(lc.loc[key, "learned_minus_rules"] - x) > 0.5:
        lv = lc.loc[key, "learned_minus_rules"]
        ax.plot(lv, yi, "D", color=INK, ms=6, label="After learning from the holdout" if n == "Reminders have no effect" else None)
ax.axvline(0, color=INK2, lw=0.8)
ax.set_yticks(y); ax.set_yticklabels(order, color=INK); ax.set_xlim(-16, 15)
ax.set_xlabel("Planner minus best rules, ₹ lakh over 2 months (40k subscribers; mean of 2 runs)")
fig.suptitle("If reminders work worse than assumed, the planner loses, until the holdout teaches it", x=0.01, ha="left", color=INK, fontsize=11)
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
ax.legend(handles=[Patch(color=BLUE, label="Planner ahead (fixed assumptions)"), Patch(color=GRAY, label="Planner behind (fixed assumptions)"),
                   Line2D([], [], marker="D", color=INK, ls="", ms=6, label="After learning from the holdout")],
          frameon=False, loc="lower right", fontsize=9)
clean(ax); fig.tight_layout(); fig.savefig("charts/5_sensitivity.png", dpi=180); plt.close(fig)
print("charts done")
