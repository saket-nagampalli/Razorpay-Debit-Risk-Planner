"""Train the pre-debit risk model: P(first attempt fails) and P(fails for insufficient funds).
Train on cycles 3-8, validate/calibrate on 9-10, test on 11-12 (out of time)."""
import json, pickle
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import roc_auc_score, brier_score_loss
import sim

FEATS = ["merchant", "category", "rail", "bank_tier", "amount", "amount_over_cap", "cap_headroom", "debit_day",
         "card_expiring", "mandate_paused_now", "tenure_cycles", "n_hist", "fails_last3", "fails_last6",
         "ins_fails_last6", "tech_fails_last6", "mandate_fails_last6", "fail_rate_hist", "failed_last",
         "failed_last_ins", "consec_first_fail", "lost_last6", "recovered_last6", "retry_paid_last6",
         "payday_est", "payday_conf", "days_from_est_payday", "outage_forecast"]
NET_FEATS = ["net_payday_est", "net_days_from_payday", "net_irregular"]
PARAMS = dict(objective="binary", learning_rate=0.05, num_leaves=31, min_data_in_leaf=200,
              feature_fraction=0.9, bagging_fraction=0.8, bagging_freq=1, verbose=-1, seed=7)


def prep(df, feats=None):
    X = df[feats or FEATS].copy()
    for c in sim.CAT_COLS:
        X[c] = pd.Categorical(X[c], categories=sorted(set(sim.MERCHANTS) if c == "merchant" else
                              {"merchant": [], "category": [m["cat"] for m in sim.MERCHANTS.values()],
                               "rail": list(sim.RAILS), "bank_tier": list(sim.TIERS)}[c]))
    return X


def ks(y, p):
    o = np.argsort(p)
    y = np.asarray(y)[o]
    c1 = np.cumsum(y) / y.sum()
    c0 = np.cumsum(1 - y) / (1 - y).sum()
    return float(np.max(np.abs(c1 - c0)))


class RiskModel:
    def __init__(self, m_fail, m_ins, iso_fail, iso_ins, feats):
        self.m_fail, self.m_ins, self.iso_fail, self.iso_ins, self.feats = m_fail, m_ins, iso_fail, iso_ins, feats

    def predict(self, df):
        X = prep(df, self.feats)
        pf = self.iso_fail.predict(self.m_fail.predict(X))
        pi = self.iso_ins.predict(self.m_ins.predict(X))
        pi = np.minimum(pi, pf)
        return pf, pi

    def contributions(self, df):
        X = prep(df, self.feats)
        return self.m_fail.predict(X, pred_contrib=True)  # SHAP-style, last col = bias


def train(log, feats=FEATS):
    tr, va, te = log[log.cycle.between(3, 8)], log[log.cycle.between(9, 10)], log[log.cycle.between(11, 12)]
    out = {}
    models = {}
    for name, y in [("fail", "first_attempt_failed"), ("ins", None)]:
        ytr = tr[y] if y else (tr.first_attempt_code == 1).astype(int)
        yva = va[y] if y else (va.first_attempt_code == 1).astype(int)
        dtr = lgb.Dataset(prep(tr, feats), ytr)
        dva = lgb.Dataset(prep(va, feats), yva)
        m = lgb.train(PARAMS, dtr, 2000, valid_sets=[dva], callbacks=[lgb.early_stopping(100, verbose=False)])
        iso = IsotonicRegression(out_of_bounds="clip").fit(m.predict(prep(va, feats)), yva)
        models[name] = (m, iso)
    import model as _self  # so the pickled class resolves to model.RiskModel
    rm = _self.RiskModel(models["fail"][0], models["ins"][0], models["fail"][1], models["ins"][1], feats)
    return rm, tr, va, te


def evaluate(rm, te):
    pf, pi = rm.predict(te)
    y = te.first_attempt_failed.values
    yi = (te.first_attempt_code == 1).astype(int).values
    res = dict(
        test_rows=int(len(te)), test_fail_rate=float(y.mean()),
        auc_fail=float(roc_auc_score(y, pf)), ks_fail=ks(y, pf), gini_fail=float(2 * roc_auc_score(y, pf) - 1),
        brier_fail=float(brier_score_loss(y, pf)), brier_baseline=float(brier_score_loss(y, np.full_like(pf, y.mean()))),
        auc_ins=float(roc_auc_score(yi, pi)), ks_ins=ks(yi, pi),
    )
    # deciles
    te = te.assign(p_fail=pf, p_ins=pi)
    te["decile"] = pd.qcut(te.p_fail.rank(method="first"), 10, labels=range(1, 11)).astype(int)
    dec = te.groupby("decile").agg(debits=("p_fail", "size"), avg_pred=("p_fail", "mean"),
                                   actual_fail=("first_attempt_failed", "mean"),
                                   actual_ins=("first_attempt_code", lambda s: (s == 1).mean())).reset_index()
    dec = dec.sort_values("decile", ascending=False)
    dec["cum_capture"] = (dec.actual_fail * dec.debits).cumsum() / (te.first_attempt_failed.sum())
    # calibration (20 bins)
    te["bin"] = pd.qcut(te.p_fail.rank(method="first"), 20, labels=False)
    cal = te.groupby("bin").agg(pred=("p_fail", "mean"), actual=("first_attempt_failed", "mean")).reset_index()

    # rules vs model targeting for insufficient-funds failures at equal message volume
    rule = (te.failed_last == 1)
    k = int(rule.sum())
    top = te.p_ins.rank(ascending=False, method="first") <= k
    ins = te.first_attempt_code == 1
    rule2 = (te.ins_fails_last6 >= 2) | (te.failed_last_ins == 1)
    k2 = int(rule2.sum())
    top2 = te.p_ins.rank(ascending=False, method="first") <= k2
    res["targeting"] = dict(
        rule_failed_last=dict(messages=k, ins_failures_caught=int((rule & ins).sum()),
                              precision=float((rule & ins).sum() / k), recall=float((rule & ins).sum() / ins.sum())),
        model_same_volume=dict(messages=k, ins_failures_caught=int((top & ins).sum()),
                               precision=float((top & ins).sum() / k), recall=float((top & ins).sum() / ins.sum())),
        rule_repeat_ins=dict(messages=k2, ins_failures_caught=int((rule2 & ins).sum()),
                             precision=float((rule2 & ins).sum() / k2), recall=float((rule2 & ins).sum() / ins.sum())),
        model_same_volume_2=dict(messages=k2, ins_failures_caught=int((top2 & ins).sum()),
                                 precision=float((top2 & ins).sum() / k2), recall=float((top2 & ins).sum() / ins.sum())),
        total_ins_failures=int(ins.sum()),
        note="New customers or first-time failures have failed_last=0, so the rule misses them; the model uses payday timing, bank, amount and history together.",
    )
    # recall at top 20% of debits
    top20 = te.p_fail.rank(ascending=False, method="first") <= 0.2 * len(te)
    res["top20pct_capture_fail"] = float(te.first_attempt_failed[top20].sum() / te.first_attempt_failed.sum())
    # importance
    imp = pd.DataFrame({"feature": rm.feats, "gain": rm.m_fail.feature_importance("gain")})
    imp["share"] = imp.gain / imp.gain.sum()
    imp = imp.sort_values("share", ascending=False)
    # segment metrics
    seg = te.groupby("category").apply(lambda g: pd.Series(dict(
        debits=len(g), fail_rate=g.first_attempt_failed.mean(),
        auc=roc_auc_score(g.first_attempt_failed, g.p_fail)))).reset_index()
    return res, dec, cal, imp, seg, te


if __name__ == "__main__":
    log = pd.read_parquet("data/debits_bau.parquet")
    for tag, feats in [("", FEATS), ("_net", FEATS + NET_FEATS)]:
        rm, tr, va, te = train(log, feats)
        res, dec, cal, imp, seg, te_scored = evaluate(rm, te)
        print(f"===== model{tag or '_merchant_only'}")
        print(json.dumps({k: v for k, v in res.items() if k != "targeting"}, indent=1))
        print(json.dumps({k: (v if not isinstance(v, dict) else {kk: round(vv, 3) for kk, vv in v.items()})
                          for k, v in res["targeting"].items() if k != "note"}, indent=1))
        print(dec.round(3).to_string(index=False))
        print(imp.head(12).round(3).to_string(index=False))
        print(seg.round(3).to_string(index=False))
        with open(f"out/risk_model{tag}.pkl", "wb") as f:
            pickle.dump(rm, f)
        json.dump(res, open(f"out/model_metrics{tag}.json", "w"), indent=1)
        dec.to_csv(f"out/model_deciles{tag}.csv", index=False)
        cal.to_csv(f"out/model_calibration{tag}.csv", index=False)
        imp.to_csv(f"out/feature_importance{tag}.csv", index=False)
        seg.to_csv(f"out/model_by_segment{tag}.csv", index=False)
