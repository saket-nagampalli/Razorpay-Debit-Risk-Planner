"""Policy simulation on the out-of-time window (cycles 11-12 = Aug-Sep 2026).
Every arm starts from the same state after cycle 10 and sees the same random draws
(common random numbers), so differences come only from the policy.

Arms
  BAU          today: daily retries (UPI/card T+1..T+3, eNACH T+5), no pre-debit action
  R1_remind_all  remind every consented customer 1-2 days before + BAU retries
  R2_rules     smart fixed rules: remind if failed last cycle for insufficient funds;
               insufficient-funds retries on T+3/T+5/T+7; re-auth + card-update prompts
  MODEL        Debit Risk Planner: expected-value reminders, payday-aware retry plan,
               re-auth + card prompts; 10% random holdout gets BAU
  MODEL_SHIFT  MODEL + one-time prorated date move for repeat timing mismatches
"""
import json, pickle, copy
import numpy as np
import pandas as pd
import sim
from model import RiskModel, prep  # noqa: F401  (needed to unpickle)

LTV = sim.LTV_CYCLES
# The planner's BELIEFS about customer response. Kept fixed in sensitivity runs, so we test what happens
# when the real world differs from what the planner assumes.
PLAN = dict(read=0.70, effect=0.28, fat_low=0.0075, fat_high=0.002)
MAX_RETRY_DAY = 10   # assumption: retries allowed up to ~10 days after the scheduled date (verify with NPCI/Razorpay)


def failure_value(log):
    """Empirical cost of an insufficient-funds failure vs an on-time debit (from BAU history, cycles 3-10)."""
    h = log[log.cycle.between(3, 10)]
    ok = h[h.first_attempt_code == 0]
    ins = h[h.first_attempt_code == 1]
    lost_share = 1 - ins.collected_amount.sum() / ins.amount.sum()
    d_cancel = ins.cancelled.mean() - ok.cancelled.mean()
    rec_cost = ins.recovery_cost.mean()
    return dict(lost_share=float(lost_share), d_cancel=float(d_cancel), recovery_cost=float(rec_cost))


def holdout_mask(cust_ids, share=0.10):
    return (np.random.default_rng(99).random(int(cust_ids.max()) + 1) < share)[cust_ids]


def payday_retry_plan(f, d, use_net=False):
    est, conf = f.payday_est.values.copy(), f.payday_conf.values.copy()
    if use_net:
        ne = f.net_payday_est.values
        est = np.where(~np.isnan(ne), ne, est)
        conf = np.where(~np.isnan(ne), 5, conf)
    k0 = np.where(conf > 0, (est + 1 - d) % 30, np.nan)
    plan = np.tile(np.array([3, 5, 7]), (len(f), 1))                  # no payday estimate: same as the rule
    near = (conf > 0) & (k0 >= 1) & (k0 <= MAX_RETRY_DAY)
    plan[near] = np.column_stack([k0[near], k0[near] + 1, k0[near] + 2]).astype(int)
    paid = (conf > 0) & ((k0 == 0) | (k0 > 25))                        # payday just passed: retry fast
    plan[paid] = [1, 2, 4]
    return plan


def policy_actions(name, cust, state, f, rm, fv, hold, rm_net=None):
    use_net = name.startswith("MODEL_NET")
    if use_net:
        rm = rm_net
    n = len(cust)
    a = sim.bau_actions(cust, state)
    if name == "BAU":
        return a, None
    eligible = (f.wa_consent.values == 1) & (f.mandate_paused_now.values == 0)
    enach = cust.rail.values == "ENACH"
    if name == "R1_remind_all":
        a["nudge"] = eligible.copy()
        return a, None
    a["reauth"] = f.amount_over_cap.values == 1
    a["card_prompt"] = f.card_expiring.values == 1
    if name in ("R2_rules", "RULE_RETRY_PROMPTS"):
        a["nudge"] = eligible & (f.failed_last_ins.values == 1) & (name == "R2_rules")
        ins_plan = np.tile(np.array([3, 5, 7]), (n, 1))
        ins_plan[enach] = [5, -1, -1]
        a["retry_off_ins"] = ins_plan
        return a, None
    # ----- MODEL
    pf, pi = rm.predict(f)
    amount = f.amount.values
    v_fail = amount * fv["lost_share"] + fv["recovery_cost"] + fv["d_cancel"] * amount * LTV
    benefit = pi * PLAN["read"] * PLAN["effect"] * v_fail
    fatigue = np.where(pi < 0.10, PLAN["fat_low"], PLAN["fat_high"]) * amount * LTV
    ev = benefit - fatigue - sim.MSG_COST
    a["nudge"] = eligible & (ev > 0) & (f.amount_over_cap.values == 0) & (f.card_expiring.values == 0)
    d = state["debit_day"]
    ins_plan = payday_retry_plan(f, d, use_net)
    ins_plan[enach] = np.column_stack([ins_plan[enach][:, 0], np.full(enach.sum(), -1), np.full(enach.sum(), -1)])
    a["retry_off_ins"] = ins_plan
    if name == "MODEL_RETRY_ONLY":
        a["nudge"][:] = False
    if name == "RULES_PLUS_NUDGE":
        r2 = np.tile(np.array([3, 5, 7]), (n, 1)); r2[enach] = [5, -1, -1]
        a["retry_off_ins"] = r2
    if name.endswith("SHIFT"):
        if use_net:   # only shift customers whose payday Razorpay can see reliably and who are not irregular earners
            est = f.net_payday_est.values
            good = ~np.isnan(est) & (f.net_irregular.values == 0)
            dfp = np.where(good, (d - np.nan_to_num(est)) % 30, -1)
        else:
            est = f.payday_est.values
            good = f.payday_conf.values >= 2
            dfp = np.nan_to_num(f.days_from_est_payday.values, nan=-1)
        el = (eligible & (state["n_success"] >= 3) & (f.ins_fails_last6.values >= 2) & good
              & (dfp >= 20) & ~state["shifted"] & ~enach)
        a["shift_offer"] = el
        a["shift_to"] = np.clip(np.where(np.isnan(est), 0, (est + 2 - 1) % 30 + 1), 1, 28).astype(int)
    # holdout gets BAU
    b = sim.bau_actions(cust, state)
    for k in a:
        if k == "retry_off_ins":
            a[k] = np.where(hold[:, None], b["retry_off"], a[k])
        elif k in b and a[k].ndim == 1:
            a[k] = np.where(hold, b[k], a[k])
        elif k in b:
            a[k] = np.where(hold[:, None], b[k], a[k])
    return a, dict(p_fail=pf, p_ins=pi, ev=ev)


def run_arm(name, snap, rm, fv, rm_net=None):
    cust = snap["cust"]
    state = copy.deepcopy(snap["state"])
    hold = holdout_mask(cust.cust_id.values)
    logs = []
    for c in (11, 12):
        U = sim.uniforms(c, len(cust))
        sim.pre_cycle(cust, state, c, U)
        _, fc = sim.outages(c)
        f = sim.features(cust, state, c, fc)
        acts, pred = policy_actions(name, cust, state, f, rm, fv, hold, rm_net)
        act_before = state["active"].copy()
        L = sim.step(cust, state, c, acts, U)
        L["arm"] = name
        L["holdout"] = hold[L.cust_id.values].astype(int)
        if pred is not None:
            L["p_fail"] = pred["p_fail"][act_before]
            L["p_ins"] = pred["p_ins"][act_before]
        logs.append(L)
    return pd.concat(logs, ignore_index=True)


def summarize(L, by=None):
    g = L.groupby(by) if by else [(None, L)]
    rows = []
    for k, x in g:
        lost_future = (x.cancelled * x.amount * LTV).sum()
        r = dict(debits=len(x), first_attempt_success=1 - x.first_attempt_failed.mean(),
                 ins_failures=int((x.first_attempt_code == 1).sum()),
                 collected=x.collected_amount.sum(), billed=x.amount.sum(),
                 collection_rate=x.collected_amount.sum() / x.amount.sum(),
                 lost_debits=int((x.stage == "lost").sum()), recovery_sequences=int((x.recovery_cost > 0).sum()),
                 cancellations=int(x.cancelled.sum()), messages=int(x.msgs.sum()),
                 msg_cost=x.msgs.sum() * sim.MSG_COST, recovery_cost=x.recovery_cost.sum(),
                 lost_future_value=lost_future)
        r["net_value"] = r["collected"] - r["msg_cost"] - r["recovery_cost"] - lost_future
        if by:
            r[by if isinstance(by, str) else "key"] = k
        rows.append(r)
    return pd.DataFrame(rows)


if __name__ == "__main__":
    log = pd.read_parquet("data/debits_bau.parquet")
    snap = pickle.load(open("data/snapshot_after_c10.pkl", "rb"))
    rm = pickle.load(open("out/risk_model.pkl", "rb"))
    rm_net = pickle.load(open("out/risk_model_net.pkl", "rb"))
    fv = failure_value(log)
    print("failure value inputs", fv)
    arms = ["BAU", "R1_remind_all", "RULE_RETRY_PROMPTS", "R2_rules", "MODEL", "MODEL_SHIFT", "MODEL_NET", "MODEL_NET_SHIFT"]
    all_logs = pd.concat([run_arm(a, snap, rm, fv, rm_net) for a in arms], ignore_index=True)
    all_logs.to_parquet("data/policy_sim.parquet", index=False)

    # ---- full-population counterfactual (non-holdout customers only, so MODEL arms are fully treated)
    core = all_logs[all_logs.holdout == 0]
    s = summarize(core, "arm").set_index("arm").loc[arms]
    base = s.loc["BAU"]
    s["value_vs_BAU"] = s.net_value - base.net_value
    s["failures_prevented_pct"] = 1 - s.ins_failures / base.ins_failures
    s["lost_debits_vs_BAU_pct"] = s.lost_debits / base.lost_debits - 1
    s["cancellations_vs_BAU_pct"] = s.cancellations / base.cancellations - 1
    pd.set_option("display.width", 220)
    print(s.round(3).T.to_string())

    # ---- realistic A/B inside the MODEL_SHIFT arm: treated vs 10% holdout, per debit
    ab = all_logs[all_logs.arm == "MODEL_NET"]
    abs_ = summarize(ab, "holdout").set_index("holdout")
    per = pd.DataFrame({"debits": abs_.debits, "first_attempt_success": abs_.first_attempt_success,
                        "collection_rate": abs_.collection_rate,
                        "lost_debit_rate": abs_.lost_debits / abs_.debits,
                        "cancel_rate": abs_.cancellations / abs_.debits,
                        "messages_per_debit": abs_.messages / abs_.debits,
                        "net_value_per_rupee_billed": abs_.net_value / abs_.billed})
    print("\nA/B inside MODEL_NET arm: treated=0, holdout=1\n", per.round(4).to_string())

    # ---- by segment (MODEL_SHIFT vs BAU)
    seg = summarize(core, ["arm", "category"])
    seg[["arm", "category"]] = pd.DataFrame(seg["key"].tolist(), index=seg.index)
    piv = seg.pivot(index="category", columns="arm", values="net_value")
    deb = seg[seg.arm == "BAU"].set_index("category").debits
    segv = pd.DataFrame({"debits": deb, "value_vs_BAU": piv["MODEL_NET"] - piv["BAU"],
                         "value_rules_vs_BAU": piv["R2_rules"] - piv["BAU"]})
    segv["value_per_1000_debits"] = segv.value_vs_BAU / segv.debits * 1000
    segv["avg_ticket"] = seg[seg.arm == "BAU"].set_index("category").billed / deb
    segv["value_pct_of_billed"] = segv.value_vs_BAU / (segv.avg_ticket * segv.debits)
    print("\nBy segment (2 cycles)\n", segv.round(3).sort_values("value_per_1000_debits", ascending=False).to_string())

    # ---- SkillUp
    sk = summarize(core[core.merchant == "SkillUp"], "arm").set_index("arm").loc[arms]
    sk["value_vs_BAU"] = sk.net_value - sk.loc["BAU"].net_value
    print("\nSkillUp (2 cycles)\n", sk[["debits", "first_attempt_success", "collection_rate", "lost_debits",
                                          "cancellations", "messages", "net_value", "value_vs_BAU"]].round(3).to_string())

    s.to_csv("out/policy_summary.csv")
    segv.to_csv("out/policy_by_segment.csv")
    sk.to_csv("out/policy_skillup.csv")
    per.to_csv("out/ab_test_per_debit.csv")
    json.dump(fv, open("out/failure_value_inputs.json", "w"), indent=1)
