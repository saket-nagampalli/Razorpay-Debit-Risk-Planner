"""Re-run the policy simulation with different random draws to show the spread of results."""
import pickle, functools
import pandas as pd
import sim, evaluate as ev
from model import RiskModel  # noqa

log = pd.read_parquet("data/debits_bau.parquet")
snap = pickle.load(open("data/snapshot_after_c10.pkl", "rb"))
rm = pickle.load(open("out/risk_model.pkl", "rb"))
rm_net = pickle.load(open("out/risk_model_net.pkl", "rb"))
fv = ev.failure_value(log)
orig = sim.uniforms
rows = []
for seed in [2026, 11, 12, 13, 14]:
    sim.uniforms = functools.partial(orig, seed=seed)
    arms = ["BAU", "R1_remind_all", "RULE_RETRY_PROMPTS", "R2_rules", "MODEL", "MODEL_SHIFT", "MODEL_NET", "MODEL_NET_SHIFT"]
    L = pd.concat([ev.run_arm(a, snap, rm, fv, rm_net) for a in arms])
    s = ev.summarize(L[L.holdout == 0], "arm").set_index("arm")
    for a in arms:
        rows.append(dict(seed=seed, arm=a, value_vs_BAU=s.loc[a].net_value - s.loc["BAU"].net_value,
                         ins_prevented=1 - s.loc[a].ins_failures / s.loc["BAU"].ins_failures,
                         cancel_change=s.loc[a].cancellations / s.loc["BAU"].cancellations - 1,
                         messages=s.loc[a].messages))
r = pd.DataFrame(rows)
r.to_csv("out/robustness_by_seed.csv", index=False)
g = r.groupby("arm").agg(['mean', 'min', 'max'])
pd.set_option("display.width", 220)
print(g.round(3).to_string())
m = r.pivot(index="seed", columns="arm", values="value_vs_BAU")
for a in ["MODEL", "MODEL_NET", "MODEL_NET_SHIFT"]:
    print(f"{a} minus R2_rules by seed:", (m[a] - m.R2_rules).round(0).tolist())
