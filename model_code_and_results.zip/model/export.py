"""Export data for the prototype screens + charts for the product note.
Prototype week: SkillUp debits due 1-7 Oct 2026, scored on 24 Sep 2026 with the network-signal model."""
import json, pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import sim, evaluate as ev
from model import RiskModel  # noqa

PRIYA_ID = 2782
log = pd.read_parquet("data/debits_bau.parquet")
snap = pickle.load(open("data/snapshot_after_c12.pkl", "rb"))
rm_net = pickle.load(open("out/risk_model_net.pkl", "rb"))
fv = ev.failure_value(log)
cust, state = snap["cust"], snap["state"]
C = 13
U = sim.uniforms(C, len(cust))
sim.pre_cycle(cust, state, C, U)
_, fc = sim.outages(C)
f = sim.features(cust, state, C, fc)
hold = ev.holdout_mask(cust.cust_id.values)
acts, pred = ev.policy_actions("MODEL_NET_SHIFT", cust, state, f, None, fv, hold, rm_net)
contrib = rm_net.contributions(f)
feat_names = rm_net.feats

sel = (state["active"]) & (cust.merchant.values == "SkillUp") & (state["debit_day"] <= 7)
idx = np.where(sel)[0]


def ordinal(n):
    n = int(n)
    return f"{n}{'th' if 11 <= n % 100 <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def plural(n, w):
    return f"{int(n)} {w}{'' if int(n) == 1 else 's'}"


def to_payday(d, est):
    return int((est - d) % 30)


def reasons(i):
    row = f.iloc[i]
    c = contrib[i, :-1]
    order = np.argsort(-c)
    out = []
    used = set()
    est = row.net_payday_est if not np.isnan(row.net_payday_est) else row.payday_est
    for j in order:
        if c[j] <= 0.02 or len(out) >= 3:
            break
        n = feat_names[j]
        key = n
        if n in ("failed_last", "failed_last_ins", "consec_first_fail"):
            key = "last"
            t = (f"First attempt failed {int(row.consec_first_fail)} months in a row" if row.consec_first_fail >= 2
                 else "Last renewal failed on first attempt")
        elif n in ("ins_fails_last6", "fail_rate_hist", "fails_last6", "fails_last3"):
            key = "hist"
            if row.ins_fails_last6:
                t = f"{plural(row.ins_fails_last6, 'low-balance failure')} in the last 6 months"
            elif row.fail_rate_hist > 0:
                t = f"First attempt fails on {row.fail_rate_hist:.0%} of renewals"
            else:
                continue
        elif n in ("net_days_from_payday", "days_from_est_payday", "net_payday_est", "payday_est", "debit_day"):
            key = "timing"
            if not np.isnan(est):
                k = to_payday(row.debit_day, est)
                t = (f"Debit date is {plural(k, 'day')} before usual payday (~{ordinal(est)})" if 0 < k <= 15
                     else "Debit date falls late in the pay cycle")
            else:
                t = "Debit date falls late in the month"
        elif n == "mandate_paused_now":
            t = "Mandate is paused by the customer"
        elif n == "amount_over_cap":
            t = f"Renewal ₹{row.amount:,.0f} exceeds mandate limit"
        elif n == "card_expiring":
            t = "Card on file expires before renewal"
        elif n == "outage_forecast":
            t = "Bank maintenance scheduled on debit day"
        elif n == "bank_tier":
            t = "Bank with higher technical decline rate"
        elif n == "net_irregular":
            t = "Irregular income pattern"
        elif n in ("n_hist", "tenure_cycles"):
            key = "new"
            t = "Newer subscriber, little payment history"
        elif n == "amount":
            t = "Higher-priced plan"
        elif n in ("lost_last6", "recovered_last6", "retry_paid_last6"):
            key = "late"
            t = "Recent renewals paid late or via recovery link"
        else:
            continue
        if key in used:
            continue
        used.add(key)
        out.append(t)
    return out


rows = []
for i in idx:
    r = f.iloc[i]
    pf, pi = float(pred["p_fail"][i]), float(pred["p_ins"][i])
    amt = float(r.amount)
    d = int(state["debit_day"][i])
    retry = acts["retry_off_ins"][i]
    if hold[i]:
        action, kind = "Control group: no action (measures true impact)", "holdout"
    elif r.mandate_paused_now == 1:
        action, kind = "Mandate paused: hand to existing win-back flow, no debit attempt", "paused"
    elif acts["reauth"][i]:
        action, kind = "Ask customer to approve the new mandate limit", "reauth"
    elif acts["card_prompt"][i]:
        action, kind = "Ask customer to update the expiring card", "card"
    elif acts["nudge"][i]:
        action, kind = (f"Reminder on {max(d - 2, 1) if d > 2 else 29} {'Oct' if d > 2 else 'Sep'}"
                        f" + retry after payday ({(d + retry[0] - 1) % 30 + 1} Oct)"), "remind_retry"
    elif r.outage_forecast == 1 and pf > 0.2:
        action, kind = "Bank maintenance on debit day: no message, retry after it ends", "outage"
    elif pf >= 0.20:
        action, kind = f"No message; if it fails, retry after payday ({(d + retry[0] - 1) % 30 + 1} Oct)", "retry_plan"
    else:
        action, kind = "No action needed", "none"
    v_fail = amt * fv["lost_share"] + fv["recovery_cost"] + fv["d_cancel"] * amt * sim.LTV_CYCLES
    rows.append(dict(
        cust_id=int(cust.cust_id.iloc[i]),
        name=("Priya S." if int(cust.cust_id.iloc[i]) == PRIYA_ID else cust.display_name.iloc[i]),
        debit_date=f"2026-10-{d:02d}", amount=round(amt), rail=r.rail, bank_tier=r.bank_tier,
        p_fail=round(pf, 3), p_insufficient=round(pi, 3), rupees_at_risk=round(pf * amt),
        expected_loss_if_ignored=round(pf * v_fail),
        reasons=reasons(i), action=action, action_type=kind,
        whatsapp_consent=bool(r.wa_consent), holdout=bool(hold[i]),
        date_move_eligible=bool(acts["shift_offer"][i]),
        tenure_months=int(r.tenure_cycles), payments_on_record=int(state["n_success"][i])))
W = pd.DataFrame(rows).sort_values("expected_loss_if_ignored", ascending=False)
W["risk_band"] = pd.cut(W.p_fail, [-1, 0.20, 0.40, 2], labels=["low", "medium", "high"]).astype(str)
at_risk = W[W.p_fail >= 0.20]
summary = dict(
    merchant="SkillUp", window="1-7 Oct 2026", generated_on="2026-09-24",
    debits_due=int(len(W)), billed=int(W.amount.sum()),
    at_risk_debits=int(len(at_risk)), rupees_at_risk=int(at_risk.rupees_at_risk.sum()),
    expected_loss_if_ignored=int(at_risk.expected_loss_if_ignored.sum()),
    risk_bands={k: int(v) for k, v in W.risk_band.value_counts().items()},
    actions={k: int(v) for k, v in W.action_type.value_counts().items()},
    messages_to_send=int(W.action_type.isin(["remind_retry", "reauth", "card"]).sum()),
    date_move_eligible=int(W.date_move_eligible.sum()),
)
json.dump(dict(summary=summary, debits=W.to_dict("records")), open("out/prototype_week_plan.json", "w"), indent=1)
print(json.dumps(summary, indent=1))
print(W.head(12)[["name", "debit_date", "amount", "p_fail", "rupees_at_risk", "action_type", "reasons"]].to_string())

# ---- Priya's history
ph = log[log.cust_id == PRIYA_ID][["debit_date", "amount", "first_attempt_reason", "stage", "collect_offset_days"]].copy()
ph["amount"] = ph.amount.round()
ph["paid_on"] = [(pd.Timestamp(dd) + pd.Timedelta(days=int(o))).strftime("%d %b") if o >= 0 else None
                 for dd, o in zip(ph.debit_date, ph.collect_offset_days)]
priya = W[W.cust_id == PRIYA_ID].iloc[0].to_dict()
pc = cust[cust.cust_id == PRIYA_ID].iloc[0]
priya.update(history=ph.drop(columns="collect_offset_days").to_dict("records"),
             true_payday_hidden=int(pc.payday), net_payday_est=float(pc.net_payday_est), plan="Pro Annual Path (monthly)")
json.dump(priya, open("out/prototype_priya.json", "w"), indent=1, default=str)
print(json.dumps({k: v for k, v in priya.items() if k != "history"}, indent=1, default=str))
print(ph.to_string())
