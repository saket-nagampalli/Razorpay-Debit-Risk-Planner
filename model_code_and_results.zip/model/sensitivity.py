"""Sensitivity analysis: how do the conclusions change if the real world differs from our assumptions?
The planner's beliefs (evaluate.PLAN) stay fixed; only the simulated customer behaviour / data quality changes.
Each scenario: BAU vs best rules (R2) vs Planner with timing signals, 2 random-draw runs."""
import copy, functools, pickle, sys
import numpy as np
import pandas as pd
import sim, evaluate as ev
from model import RiskModel  # noqa

log = pd.read_parquet("data/debits_bau.parquet")
snap0 = pickle.load(open("data/snapshot_after_c10.pkl", "rb"))
rm = pickle.load(open("out/risk_model.pkl", "rb"))
rm_net = pickle.load(open("out/risk_model_net.pkl", "rb"))
fv = ev.failure_value(log)
BASE = dict(NUDGE_EFFECT=sim.NUDGE_EFFECT, FATIGUE_SCALE=1.0, CANCEL_SCALE=1.0)


def net_signal(snap, coverage=None, noise_sd=None, seed=5):
    s = dict(cust=snap["cust"].copy(), state=snap["state"])
    c = s["cust"]
    r = np.random.default_rng(seed)
    if noise_sd is not None:
        has = ~c.net_payday_est.isna()
        noise = np.round(r.normal(0, noise_sd, len(c))).astype(int)
        c.loc[has, "net_payday_est"] = ((c.loc[has, "payday"] + noise[has.values] - 1) % 30) + 1
    if coverage is not None:
        has = ~c.net_payday_est.isna()
        drop = has & (r.random(len(c)) > coverage / 0.60)
        c.loc[drop, "net_payday_est"] = np.nan
        c.loc[drop, "net_irregular"] = np.nan
    return s


SCEN = [
    ("Base case", {}, {}),
    ("Reminders have no effect", dict(NUDGE_EFFECT=0.0), {}),
    ("Reminders work half as well", dict(NUDGE_EFFECT=0.14), {}),
    ("Reminders work twice as well", dict(NUDGE_EFFECT=0.56), {}),
    ("No reminder fatigue", dict(FATIGUE_SCALE=0.0), {}),
    ("Reminder fatigue 3x", dict(FATIGUE_SCALE=3.0), {}),
    ("Failures cause half the cancellations", dict(CANCEL_SCALE=0.5), {}),
    ("Failures cause 1.5x the cancellations", dict(CANCEL_SCALE=1.5), {}),
    ("Timing signal for 30% of payers (not 60%)", {}, dict(coverage=0.30)),
    ("Timing signal off by ~3 days", {}, dict(noise_sd=3.0)),
    ("Timing signal off by ~6 days", {}, dict(noise_sd=6.0)),
    ("No timing signal at all", {}, dict(coverage=0.0)),
    ("Pessimistic combined", dict(NUDGE_EFFECT=0.14, FATIGUE_SCALE=2.0, CANCEL_SCALE=0.75), dict(noise_sd=3.0)),
]

rows = []
orig = sim.uniforms
for name, world, netp in SCEN:
    for k, v in {**BASE, **world}.items():
        setattr(sim, k, v)
    snap = net_signal(snap0, **netp) if netp else snap0
    for seed in [2026, 11]:
        sim.uniforms = functools.partial(orig, seed=seed)
        L = pd.concat([ev.run_arm(a, snap, rm, fv, rm_net) for a in ["BAU", "R2_rules", "MODEL_NET"]])
        s = ev.summarize(L[L.holdout == 0], "arm").set_index("arm")
        b = s.loc["BAU"]
        rows.append(dict(scenario=name, seed=seed,
                         rules_vs_today=(s.loc["R2_rules"].net_value - b.net_value) / 1e5,
                         planner_vs_today=(s.loc["MODEL_NET"].net_value - b.net_value) / 1e5,
                         planner_cancel_change=s.loc["MODEL_NET"].cancellations / b.cancellations - 1,
                         rules_cancel_change=s.loc["R2_rules"].cancellations / b.cancellations - 1,
                         planner_ins_prevented=1 - s.loc["MODEL_NET"].ins_failures / b.ins_failures,
                         planner_messages=s.loc["MODEL_NET"].messages))
        print(name, seed, round(rows[-1]["rules_vs_today"], 1), round(rows[-1]["planner_vs_today"], 1), flush=True)
    for k, v in BASE.items():
        setattr(sim, k, v)
sim.uniforms = orig
r = pd.DataFrame(rows)
r.to_csv("out/sensitivity_runs.csv", index=False)
g = r.groupby("scenario", sort=False).mean(numeric_only=True).drop(columns="seed")
g["planner_minus_rules"] = g.planner_vs_today - g.rules_vs_today
g["planner_vs_rules_pct"] = g.planner_minus_rules / g.rules_vs_today
g.to_csv("out/sensitivity_summary.csv")
pd.set_option("display.width", 220)
print(g.round(3).to_string())
