"""Learning-loop check. When the real reminder response differs from the planner's assumption, compare:
  fixed  = planner keeps its original beliefs (numbers from sensitivity.py)
  learned = planner beliefs updated to what the 10% holdout would measure after a few cycles
Shows whether the learning loop recovers the value."""
import functools, pickle
import pandas as pd
import sim, evaluate as ev
from model import RiskModel  # noqa

log = pd.read_parquet("data/debits_bau.parquet")
snap = pickle.load(open("data/snapshot_after_c10.pkl", "rb"))
rm = pickle.load(open("out/risk_model.pkl", "rb"))
rm_net = pickle.load(open("out/risk_model_net.pkl", "rb"))
fv = ev.failure_value(log)
BASE_PLAN = dict(ev.PLAN)
BASE = dict(NUDGE_EFFECT=sim.NUDGE_EFFECT, FATIGUE_SCALE=1.0, CANCEL_SCALE=1.0)

SCEN = [
    ("Reminders have no effect", dict(NUDGE_EFFECT=0.0)),
    ("Reminders work half as well", dict(NUDGE_EFFECT=0.14)),
    ("Reminder fatigue 3x", dict(FATIGUE_SCALE=3.0)),
    ("Reminders work twice as well", dict(NUDGE_EFFECT=0.56)),
    ("Pessimistic combined (reminder part)", dict(NUDGE_EFFECT=0.14, FATIGUE_SCALE=2.0)),
]
rows = []
orig = sim.uniforms
for name, world in SCEN:
    for k, v in {**BASE, **world}.items():
        setattr(sim, k, v)
    ev.PLAN.update(effect=sim.NUDGE_EFFECT, fat_low=BASE_PLAN["fat_low"] * sim.FATIGUE_SCALE,
                   fat_high=BASE_PLAN["fat_high"] * sim.FATIGUE_SCALE)
    for seed in [2026, 11]:
        sim.uniforms = functools.partial(orig, seed=seed)
        L = pd.concat([ev.run_arm(a, snap, rm, fv, rm_net) for a in ["BAU", "R2_rules", "MODEL_NET"]])
        s = ev.summarize(L[L.holdout == 0], "arm").set_index("arm")
        b = s.loc["BAU"]
        rows.append(dict(scenario=name, seed=seed,
                         rules_vs_today=(s.loc["R2_rules"].net_value - b.net_value) / 1e5,
                         learned_planner_vs_today=(s.loc["MODEL_NET"].net_value - b.net_value) / 1e5,
                         learned_messages=s.loc["MODEL_NET"].messages))
        print(rows[-1], flush=True)
    ev.PLAN.clear(); ev.PLAN.update(BASE_PLAN)
    for k, v in BASE.items():
        setattr(sim, k, v)
sim.uniforms = orig
r = pd.DataFrame(rows)
g = r.groupby("scenario", sort=False).mean(numeric_only=True).drop(columns="seed")
fixed = pd.read_csv("out/sensitivity_summary.csv").set_index("scenario")
g["fixed_planner_vs_today"] = [fixed.loc[n if "combined" not in n else n, "planner_vs_today"]
                               if n in fixed.index else float("nan") for n in g.index]
g["learned_minus_rules"] = g.learned_planner_vs_today - g.rules_vs_today
g.to_csv("out/learning_check.csv")
pd.set_option("display.width", 200)
print(g.round(2).to_string())
