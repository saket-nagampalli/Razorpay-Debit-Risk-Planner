"""
Debit Risk Planner — synthetic recurring-debit simulator.

One engine is used both to generate the 12-month history (business as usual)
and to evaluate policies (BAU vs rules vs model), so every arm obeys the same
customer behaviour. All behavioural parameters are MODELLING ASSUMPTIONS
anchored to public figures (see README / research dossier), not real data.

Timeline: cycle 1 = Oct 2025 ... cycle 12 = Sep 2026. Months are simplified
to 30 days; debit days run 1..28.
"""
import numpy as np
import pandas as pd

# ---------------------------------------------------------------- constants
MONTHS = pd.period_range("2025-10", periods=13, freq="M")  # cycle c -> MONTHS[c-1]

MERCHANTS = {
    # name: category, n, plans, plan probs, rail mix (UPI, CARD, ENACH), affordability factor, archetype mix
    "SkillUp":    dict(cat="edtech",    n=8000,  plans=[1499, 2499, 3999], pp=[.3, .5, .2],
                       rails=[.80, .15, .05], aff=1.15, arch=[.289, .124, .263, .25, .074]),
    "FitNation":  dict(cat="fitness",   n=6000,  plans=[799, 1199, 1999], pp=[.3, .5, .2],
                       rails=[.75, .20, .05], aff=1.05, arch=[.366, .157, .332, .05, .095]),
    "DailyDose":  dict(cat="d2c",       n=8000,  plans=[499, 699, 1199], pp=[.3, .5, .2],
                       rails=[.70, .25, .05], aff=0.95, arch=[.366, .157, .332, .05, .095]),
    "StreamBox":  dict(cat="ott",       n=12000, plans=[149, 199, 499], pp=[.3, .5, .2],
                       rails=[.70, .30, .00], aff=0.75, arch=[.327, .140, .298, .15, .085]),
    "SecureLife": dict(cat="insurance_sip", n=6000, plans=[1500, 3000, 6000, 18000], pp=[.25, .45, .25, .05],
                       rails=[.45, .15, .40], aff=1.20, arch=[.343, .147, .245, .02, .245]),
}
RAILS = np.array(["UPI", "CARD", "ENACH"])
# Archetype mix anchored to PLFS 2023-24 urban workers: 47.5% regular wage/salaried,
# 40.4% self-employed, 12.1% casual (irregular income). Tilted slightly to salaried because
# digital-subscription payers skew formal; students and affluent added per merchant.
ARCH = np.array(["salaried_monthend", "salaried_5to10", "gig_irregular", "student_dependent", "affluent"])
ARCH_BASE = np.array([0.06, 0.07, 0.18, 0.15, 0.02])     # dossier table 11(b)
RAIL_INS_FACTOR = np.array([1.0, 0.45, 1.25])             # cards: credit limits; eNACH: bigger tickets
TIERS = np.array(["A", "B", "C"])
TIER_P = [.35, .40, .25]
# Technical declines by bank tier, anchored to NPCI UPI data (Mar 2025, via Hindu BusinessLine):
# large private banks 0.02-0.13%, SBI 0.9%, smaller / payments banks 2.5-7.2%. Mandate execution adds overhead.
TECH_BASE = {"UPI": np.array([.0015, .009, .035]), "CARD": np.array([.006, .006, .006]),
             "ENACH": np.array([.005, .012, .030])}
OUTAGE_DAYS_PER_TIER = 2
OUTAGE_P_TECH = 0.30
GLOBAL_INS_SCALE = 1.1          # calibrated so UPI first-attempt failure ~20% (Razorpay-published anchor)

N_SLOTS = 24                     # uniforms per customer-cycle (common random numbers)
LTV_CYCLES = 6                   # value of a cancelled subscriber = 6 more cycles
MSG_COST = 0.5                   # ₹ per WhatsApp utility message (assumption)
RECOVERY_COST = 6.0              # ₹ per post-failure recovery sequence (WhatsApp + voice)
NUDGE_READ = 0.70
NUDGE_EFFECT = 0.28              # relative cut in P(insufficient funds) if read. Evidence range: generic SMS
                                 # reminders ~no effect (Karlan, Morten & Zinman, Philippines); +9% on-time payment
                                 # (Cadena & Schoar, Uganda); personalised -41% unpaid. 0.28 x 0.70 read ~ -20% if sent.
FATIGUE_LOW = 0.0075             # extra cancel prob if nudged while truly low-risk (p<0.10)
FATIGUE_HIGH = 0.002
FATIGUE_SCALE = 1.0              # sensitivity knob
CANCEL_SCALE = 1.0               # sensitivity knob: scales extra cancellation risk after a failure

REASONS = ["ok", "insufficient_funds", "technical", "mandate_issue", "other"]
# detailed codes -> model classes
DETAIL = ["ok", "insufficient_funds", "technical", "notification_failed", "mandate_paused",
          "limit_exceeded", "card_expired", "account_issue"]
DETAIL_TO_CLASS = {0: 0, 1: 1, 2: 2, 3: 2, 4: 3, 5: 3, 6: 3, 7: 4}

FIRST = ["Priya", "Rahul", "Ananya", "Arjun", "Sneha", "Vikram", "Kavya", "Rohan", "Meera", "Aditya",
         "Ishita", "Karan", "Divya", "Siddharth", "Pooja", "Nikhil", "Tanvi", "Aman", "Riya", "Varun",
         "Neha", "Harsh", "Shruti", "Manish", "Aisha", "Deepak", "Lakshmi", "Suresh", "Fatima", "Gaurav"]
LAST = list("ABCDEGHJKMNPRSTV")


# ---------------------------------------------------------------- customers
def make_customers(rng, merchant, n, cycle_joined=1, start_id=0, prior_tenure=True):
    m = MERCHANTS[merchant]
    c = pd.DataFrame({"cust_id": np.arange(start_id, start_id + n)})
    c["merchant"] = merchant
    c["category"] = m["cat"]
    c["plan_amount"] = rng.choice(m["plans"], n, p=m["pp"]).astype(float)
    c["rail"] = rng.choice(RAILS, n, p=m["rails"])
    c["bank_tier"] = rng.choice(TIERS, n, p=TIER_P)
    a = rng.choice(len(ARCH), n, p=np.array(m["arch"]) / np.sum(m["arch"]))
    c["archetype"] = ARCH[a]
    pay = np.empty(n, int)
    pay[a == 0] = 30
    pay[a == 1] = rng.integers(5, 11, (a == 1).sum())
    pay[a == 2] = rng.integers(0, 7, (a == 2).sum())        # weekday offset
    pay[a == 3] = rng.integers(1, 29, (a == 3).sum())       # usual transfer day
    pay[a == 4] = rng.integers(1, 31, (a == 4).sum())
    c["payday"] = pay
    c["stress"] = rng.lognormal(0, 0.5, n)
    c["debit_day"] = rng.integers(1, 29, n)
    c["cap_mult"] = rng.choice([1.0, 1.5, 2.0], n, p=[.4, .35, .25])
    # 60% of card mandates are auto-updated via network token lifecycle -> never expire here
    c["card_expiry_cycle"] = np.where((c["rail"] == "CARD") & (rng.random(n) < 0.40), rng.integers(1, 49, n), 999)
    c["prior_tenure"] = rng.integers(0, 19, n) if prior_tenure else 0
    c["cycle_joined"] = cycle_joined
    c["wa_consent"] = rng.random(n) < 0.90
    c["price_change_flag"] = (merchant == "SkillUp") & (rng.random(n) < 0.30)
    # Razorpay network signal (aggregated, consented; never shown to the merchant):
    # ~60% of payers make enough other Razorpay payments for inflow timing to be visible.
    has_net = rng.random(n) < 0.60
    c["net_signal"] = has_net
    noise = np.round(rng.normal(0, 1.2, n)).astype(int)
    monthly = np.isin(a, [0, 1, 3, 4])
    c["net_payday_est"] = np.where(has_net & monthly, ((pay + noise - 1) % 30) + 1, np.nan)
    true_irreg = np.isin(a, [2, 3])
    c["net_irregular"] = np.where(has_net, np.where(rng.random(n) < 0.85, true_irreg, ~true_irreg).astype(float), np.nan)
    c["display_name"] = [f"{FIRST[i]} {LAST[j]}." for i, j in
                         zip(rng.integers(0, len(FIRST), n), rng.integers(0, len(LAST), n))]
    return c


def all_customers(rng):
    out, sid = [], 0
    for name, m in MERCHANTS.items():
        out.append(make_customers(rng, name, m["n"], start_id=sid))
        sid += m["n"]
    return pd.concat(out, ignore_index=True)


# ---------------------------------------------------------------- state
def new_state(n):
    return dict(
        active=np.ones(n, bool),
        hist_code=np.full((n, 6), -1, int),     # first-attempt detail code, last 6 cycles (col 0 = most recent)
        hist_stage=np.full((n, 6), -1, int),    # 0 on_time 1 retry 2 recovered 3 lost
        n_hist=np.zeros(n, int),
        n_success=np.zeros(n, int),
        consec_first_fail=np.zeros(n, int),
        consec_lost=np.zeros(n, int),
        paused=np.zeros(n, bool),
        paused_cycles=np.zeros(n, int),
        cap=np.zeros(n),                        # set from plan at join
        card_updated=np.zeros(n, bool),
        plan_mult=np.ones(n),
        pd_sin=np.zeros(n), pd_cos=np.zeros(n), pd_n=np.zeros(n, int),   # payday evidence (circular)
        debit_day=np.zeros(n, int),
        shifted=np.zeros(n, bool),
        msgs_this_cycle=np.zeros(n, int),
    )


def extend_state(state, k, cust_new):
    for key, v in state.items():
        if v.ndim == 1:
            fill = {bool: False}.get(v.dtype.type, 0)
            ext = np.full(k, fill, dtype=v.dtype)
            if key == "active":
                ext[:] = True
            state[key] = np.concatenate([v, ext])
        else:
            state[key] = np.concatenate([v, np.full((k, v.shape[1]), -1, v.dtype)])
    idx = np.arange(len(state["active"]) - k, len(state["active"]))
    state["cap"][idx] = cust_new["plan_amount"].values * cust_new["cap_mult"].values
    state["debit_day"][idx] = cust_new["debit_day"].values
    state["plan_mult"][idx] = 1.0


# ---------------------------------------------------------------- environment
def outages(cycle, seed=777):
    """Bank-tier outage days for a cycle (same in every policy arm). 50% are forecastable."""
    r = np.random.default_rng(seed * 100 + cycle)
    days = {t: r.choice(np.arange(1, 31), OUTAGE_DAYS_PER_TIER, replace=False) for t in TIERS}
    fc = {t: days[t][r.random(OUTAGE_DAYS_PER_TIER) < 0.5] for t in TIERS}
    return days, fc


def uniforms(cycle, n, seed=2026):
    return np.random.default_rng(seed * 1000 + cycle).random((n, N_SLOTS))


def timing_mult(days_since):
    """Dossier 11(c): multiplier on P(insufficient funds) by days since payday (monthly earners)."""
    return np.select([days_since <= 2, days_since <= 10, days_since <= 19, days_since <= 27],
                     [0.6, 0.8, 1.0, 1.5], 2.0)


def gig_mult(ds7):
    return np.select([ds7 <= 1, ds7 <= 4], [0.7, 1.0], 1.4)


def actual_payday(cust, U):
    """This cycle's realised payday (salary delays, student transfer noise)."""
    a = cust["archetype"].values
    pd_ = cust["payday"].values.copy()
    delay = (U[:, 0] < 0.05) * (1 + (U[:, 1] * 3).astype(int))         # 5% delayed 1-3 days
    monthly = (a == "salaried_monthend") | (a == "salaried_5to10")
    pd_ = np.where(monthly, pd_ + delay, pd_)
    stud = a == "student_dependent"
    pd_ = np.where(stud, pd_ + np.round((U[:, 2] - 0.5) * 10).astype(int), pd_)
    return pd_


def days_since(day, pd_, a):
    gig = a == "gig_irregular"
    return np.where(gig, (day - pd_) % 7, (day - pd_) % 30)


def p_insufficient(cust, state, day, pd_, U):
    a = cust["archetype"].values
    base = pd.Series(a).map(dict(zip(ARCH, ARCH_BASE))).values
    ds = days_since(day, pd_, a)
    mult = np.where(a == "gig_irregular", gig_mult(ds),
                    np.where(a == "affluent", 1.0, timing_mult(ds)))
    rail_f = np.where(cust["rail"].values == "UPI", 1.0, np.where(cust["rail"].values == "CARD", 0.45, 1.25))
    aff = cust["merchant"].map({k: v["aff"] for k, v in MERCHANTS.items()}).values
    p = GLOBAL_INS_SCALE * base * cust["stress"].values * mult * rail_f * aff
    p = np.clip(p, 0, 0.85)
    # state dependence: failed for insufficient funds last cycle -> odds x2.5
    last_ins = state["hist_code"][:, 0] == 1
    odds = p / (1 - p) * np.where(last_ins, 2.5, 1.0)
    return np.clip(odds / (1 + odds), 0, 0.92), ds


def retry_ins_success(cust, d, off, pd_, a):
    """Insufficient-funds retry: 55% if payday fell in (d, d+off], else 10%; affluent 60%."""
    per = np.where(a == "gig_irregular", 7, 30)
    crossed = ((d + off - pd_) % per) < off
    p = np.where(crossed, 0.55, 0.10)
    return np.where(a == "affluent", 0.60, p)


# ---------------------------------------------------------------- pre-debit features (no leakage)
def features(cust, state, cycle, fc_outage):
    n = len(cust)
    hc, hs = state["hist_code"], state["hist_stage"]
    has = hc >= 0
    f = pd.DataFrame(index=cust.index)
    f["merchant"] = cust["merchant"].values
    f["category"] = cust["category"].values
    f["rail"] = cust["rail"].values
    f["bank_tier"] = cust["bank_tier"].values
    amount = cust["plan_amount"].values * state["plan_mult"]
    f["amount"] = amount
    f["amount_over_cap"] = (amount > state["cap"] + 1e-6).astype(int)
    f["cap_headroom"] = state["cap"] / amount
    f["debit_day"] = state["debit_day"]
    f["card_expiring"] = ((cust["rail"].values == "CARD") & (cust["card_expiry_cycle"].values <= cycle)
                          & ~state["card_updated"]).astype(int)
    f["mandate_paused_now"] = state["paused"].astype(int)
    f["tenure_cycles"] = cust["prior_tenure"].values + (cycle - cust["cycle_joined"].values)
    f["n_hist"] = state["n_hist"]
    f["fails_last3"] = ((hc[:, :3] > 0)).sum(1)
    f["fails_last6"] = ((hc > 0)).sum(1)
    f["ins_fails_last6"] = (hc == 1).sum(1)
    f["tech_fails_last6"] = np.isin(hc, [2, 3]).sum(1)
    f["mandate_fails_last6"] = np.isin(hc, [4, 5, 6]).sum(1)
    f["fail_rate_hist"] = np.where(has.sum(1) > 0, (hc > 0).sum(1) / np.maximum(has.sum(1), 1), np.nan)
    f["failed_last"] = (hc[:, 0] > 0).astype(int)
    f["failed_last_ins"] = (hc[:, 0] == 1).astype(int)
    f["consec_first_fail"] = state["consec_first_fail"]
    f["lost_last6"] = (hs == 3).sum(1)
    f["recovered_last6"] = (hs == 2).sum(1)
    f["retry_paid_last6"] = (hs == 1).sum(1)
    conf = state["pd_n"]
    ang = np.arctan2(state["pd_sin"], state["pd_cos"])
    est = np.where(conf > 0, np.round((ang % (2 * np.pi)) / (2 * np.pi) * 30), np.nan)
    est = np.where(est == 0, 30, est)
    f["payday_est"] = est
    f["payday_conf"] = conf
    f["days_from_est_payday"] = np.where(conf > 0, (state["debit_day"] - est) % 30, np.nan)
    tier = cust["bank_tier"].values
    f["outage_forecast"] = np.array([state["debit_day"][i] in fc_outage[tier[i]] for i in range(n)]).astype(int)
    f["wa_consent"] = cust["wa_consent"].values.astype(int)
    ne = cust["net_payday_est"].values
    f["net_payday_est"] = ne
    f["net_days_from_payday"] = np.where(np.isnan(ne), np.nan, (state["debit_day"] - ne) % 30)
    f["net_irregular"] = cust["net_irregular"].values
    return f


CAT_COLS = ["merchant", "category", "rail", "bank_tier"]


# ---------------------------------------------------------------- one cycle
def pre_cycle(cust, state, cycle, U):
    """Plan / price changes that happen before the debit (visible to merchant and model)."""
    act = state["active"]
    pc = cust["price_change_flag"].values & (cycle == 9)
    state["plan_mult"] = np.where(pc, 1.2, state["plan_mult"])
    up = (U[:, 3] < 0.005) & act
    state["plan_mult"] = np.where(up, state["plan_mult"] * (1.25 + 0.35 * U[:, 4]), state["plan_mult"])

def bau_actions(cust, state):
    n = len(cust)
    off = np.tile(np.array([1, 2, 3]), (n, 1))
    enach = cust["rail"].values == "ENACH"
    off[enach] = [5, -1, -1]
    return dict(nudge=np.zeros(n, bool), reauth=np.zeros(n, bool), card_prompt=np.zeros(n, bool),
                shift_offer=np.zeros(n, bool), shift_to=np.zeros(n, int), retry_off=off)


def step(cust, state, cycle, actions, U, true_p_out=None):
    """Simulate one billing cycle for active customers. Returns a log DataFrame (one row per debit)."""
    n = len(cust)
    act = state["active"].copy()
    a = cust["archetype"].values
    rail = cust["rail"].values
    tier = cust["bank_tier"].values
    out_days, fc = outages(cycle)

    feats = features(cust, state, cycle, fc)
    d = state["debit_day"].copy()
    amount = cust["plan_amount"].values * state["plan_mult"]
    msgs = np.zeros(n)

    # --- pre-debit actions
    reauth_ok = actions["reauth"] & (U[:, 5] < 0.45)
    state["cap"] = np.where(reauth_ok, np.maximum(state["cap"], amount * 1.5), state["cap"])
    card_ok = actions["card_prompt"] & (U[:, 6] < 0.50)
    state["card_updated"] |= card_ok
    msgs += actions["reauth"] + actions["card_prompt"]

    pd_ = actual_payday(cust, U)
    p_ins, ds = p_insufficient(cust, state, d, pd_, U)
    read = actions["nudge"] & (U[:, 7] < NUDGE_READ)
    p_ins_eff = p_ins * np.where(read, 1 - NUDGE_EFFECT, 1.0)
    msgs += actions["nudge"]

    # --- first attempt
    is_out = np.array([d[i] in out_days[tier[i]] for i in range(n)])
    tb = np.zeros(n)
    for r in ["UPI", "CARD", "ENACH"]:
        m = rail == r
        tb[m] = TECH_BASE[r][np.searchsorted(TIERS, tier[m])]
    p_tech = np.where(is_out, OUTAGE_P_TECH, tb)
    card_exp = (rail == "CARD") & (cust["card_expiry_cycle"].values <= cycle) & ~state["card_updated"]
    code = np.zeros(n, int)
    code = np.where(U[:, 12] < p_ins_eff, 1, code)
    code = np.where((rail != "ENACH") & (U[:, 11] < 0.004), 7, code)               # account closed/frozen
    code = np.where((rail == "UPI") & (U[:, 10] < 0.012), 3, code)                 # pre-debit notification failed
    code = np.where(U[:, 9] < p_tech, 2, code)
    code = np.where(amount > state["cap"] + 1e-6, 5, code)
    code = np.where(card_exp, 6, code)
    code = np.where(state["paused"], 4, code)
    code = np.where(act, code, -1)

    # --- retries
    stage = np.where(code == 0, 0, -1)
    coll_off = np.where(code == 0, 0, -1)
    attempts = np.ones(n, int)
    pending = (code > 0)
    off_ins = actions.get("retry_off_ins", actions["retry_off"])   # reason-aware plan (reason code is known at failure)
    for k in range(3):
        off = np.where(code == 1, off_ins[:, k], actions["retry_off"][:, k])
        go = pending & (off > 0)
        attempts += go
        rday = d + off
        r_out = np.array([((rday[i] - 1) % 30 + 1) in out_days[tier[i]] for i in range(n)])
        p_s = np.zeros(n)
        p_s = np.where(code == 1, retry_ins_success(cust, d, off, pd_, a), p_s)
        p_s = np.where(code == 2, np.where(r_out, 0.30, 0.70), p_s)
        p_s = np.where(code == 3, 0.85, p_s)
        win = go & (U[:, 13 + k] < p_s)
        stage = np.where(win, 1, stage)
        coll_off = np.where(win, off, coll_off)
        pending &= ~win

    # --- post-failure recovery (existing Razorpay agents; same in every arm)
    exhausted = pending.copy()
    p_rec = np.select([np.isin(code, [1, 2, 3]), np.isin(code, [4, 5, 6])], [0.45, 0.30], 0.0)
    rec = exhausted & (U[:, 16] < p_rec)
    plan = np.where((code == 1)[:, None], off_ins, actions["retry_off"])
    last_off = np.maximum(plan.max(1), 0)
    to_pay = np.where(a == "gig_irregular", (pd_ - d) % 7, (pd_ - d) % 30)
    rec_off = np.where(to_pay <= last_off, last_off + 1 + (U[:, 17] * 5).astype(int), to_pay + (U[:, 17] * 4).astype(int))
    rec_off = np.where(np.isin(code, [2, 3]), last_off + 1 + (U[:, 17] * 3).astype(int), rec_off)
    rec_off = np.where(np.isin(code, [4, 5, 6]), 3 + (U[:, 17] * 8).astype(int), rec_off)
    stage = np.where(rec, 2, stage)
    coll_off = np.where(rec, rec_off, coll_off)
    stage = np.where(exhausted & ~rec, 3, stage)
    stage = np.where(act, stage, -1)

    collected = np.isin(stage, [0, 1, 2])
    recovery_cost = exhausted * RECOVERY_COST

    # --- payday evidence from late collections after insufficient-funds failures
    ev = (code == 1) & np.isin(stage, [1, 2])
    ev_day = ((d + coll_off - 1) % 30) + 1 - 1
    ev_day = np.where(ev_day == 0, 30, ev_day)
    th = 2 * np.pi * ev_day / 30
    state["pd_sin"] += np.where(ev, np.sin(th), 0)
    state["pd_cos"] += np.where(ev, np.cos(th), 0)
    state["pd_n"] += ev

    # --- cancellations / pauses (end of cycle)
    consec_lost_new = np.where(stage == 3, state["consec_lost"] + 1, 0)
    p_cancel = np.select([stage == 0, stage == 1, stage == 2, (stage == 3) & (consec_lost_new >= 2), stage == 3],
                         [0.010, 0.03, 0.08, 0.50, 0.30], 0.0)
    p_cancel = np.where(p_cancel > 0.010, 0.010 + CANCEL_SCALE * (p_cancel - 0.010), p_cancel)
    p_cancel = np.where(code == 4, 0.0, p_cancel)                 # paused handled below
    p_cancel = p_cancel + np.where(actions["nudge"], FATIGUE_SCALE * np.where(p_ins < 0.10, FATIGUE_LOW, FATIGUE_HIGH), 0)
    cancel = act & (U[:, 18] < p_cancel)
    cancel |= act & (code == 7)
    # pause dynamics
    was_paused = state["paused"].copy()
    resume = was_paused & (U[:, 19] < 0.5)
    pause_new = act & ~was_paused & ~cancel & (U[:, 20] < np.where(stage == 3, 0.04, 0.006))
    state["paused"] = (was_paused & ~resume) | pause_new
    state["paused_cycles"] = np.where(state["paused"], state["paused_cycles"] + 1, 0)
    cancel |= act & (state["paused_cycles"] >= 3)
    state["paused"] &= ~cancel

    # --- date shift (takes effect next cycle)
    shift_acc = actions["shift_offer"] & (U[:, 21] < 0.40) & act & ~cancel
    msgs += actions["shift_offer"]

    # --- customer fixes the mandate when they pay through a recovery link
    state["cap"] = np.where((code == 5) & (stage == 2), amount * 1.5, state["cap"])
    state["card_updated"] |= (code == 6) & (stage == 2)

    # --- state update
    state["hist_code"] = np.where(act[:, None], np.column_stack([code, state["hist_code"][:, :5]]), state["hist_code"])
    state["hist_stage"] = np.where(act[:, None], np.column_stack([stage, state["hist_stage"][:, :5]]), state["hist_stage"])
    state["n_hist"] += act
    state["n_success"] += act & collected
    state["consec_first_fail"] = np.where(act, np.where(code > 0, state["consec_first_fail"] + 1, 0), state["consec_first_fail"])
    state["consec_lost"] = np.where(act, consec_lost_new, state["consec_lost"])
    state["debit_day"] = np.where(shift_acc, actions["shift_to"], state["debit_day"])
    state["shifted"] |= shift_acc
    state["active"] = act & ~cancel

    month = MONTHS[cycle - 1]
    log = feats.copy()
    log.insert(0, "cust_id", cust["cust_id"].values)
    log.insert(1, "cycle", cycle)
    log.insert(2, "debit_date", [f"{month.year}-{month.month:02d}-{int(x):02d}" for x in d])
    log["archetype"] = a                                  # hidden truth (not a model feature)
    log["payday_true"] = pd_
    log["true_p_insufficient"] = p_ins
    log["nudged"] = actions["nudge"].astype(int)
    log["reauth_prompt"] = actions["reauth"].astype(int)
    log["card_prompt"] = actions["card_prompt"].astype(int)
    log["shift_offered"] = actions["shift_offer"].astype(int)
    log["shift_accepted"] = shift_acc.astype(int)
    log["first_attempt_code"] = code
    log["first_attempt_reason"] = [DETAIL[x] if x >= 0 else "" for x in code]
    log["label_class"] = [DETAIL_TO_CLASS.get(x, -1) for x in code]
    log["first_attempt_failed"] = (code > 0).astype(int)
    log["attempts"] = attempts
    log["stage"] = np.array(["on_time", "retry", "recovered", "lost", ""])[np.where(stage >= 0, stage, 4)]
    log["collect_offset_days"] = coll_off
    log["collected_amount"] = np.where(collected, amount, 0.0)
    log["msgs"] = msgs
    log["recovery_cost"] = recovery_cost
    log["cancelled"] = cancel.astype(int)
    log["outage_on_day"] = is_out.astype(int)
    return log[act].reset_index(drop=True)
